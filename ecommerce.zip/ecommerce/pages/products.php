<?php
session_start(); // ✅ NEW: Start session for cart

// Connect to MySQL
$conn = new mysqli("localhost", "root", "", "ecommerce");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch products
$sql = "SELECT * FROM products";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Products - My E-Commerce Site</title>
    <style>
        body { font-family: Arial; margin: 0; background: #f4f4f4; }
        header, nav { background: #333; color: white; padding: 10px; text-align: center; }
        nav a { color: white; margin: 0 10px; text-decoration: none; }
        nav a:hover { text-decoration: underline; }
        .products { display: flex; flex-wrap: wrap; justify-content: center; padding: 20px; }
        .product {
            background: white;
            border: 1px solid #ccc;
            border-radius: 8px;
            margin: 10px;
            padding: 15px;
            width: 220px;
            text-align: center;
        }
        .product img { width: 100%; border-radius: 5px; }
        .product h3 { margin: 10px 0 5px; }
        .product p { margin: 5px 0; font-weight: bold; color: green; }
        .product form { margin-top: 10px; }
        .product button {
            padding: 8px 12px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .product button:hover {
            background: #218838;
        }
    </style>
</head>
<body>

<header>
    <h1>Our Products</h1>
</header>

<nav>
    <a href="../index.php">Home</a>
    <a href="products.php">Products</a>
    <a href="cart.php">View Cart 🛒</a> <!-- ✅ NEW -->
</nav>

<div class="products">
    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo '<div class="product">';
            echo '<img src="' . $row["image"] . '" alt="' . $row["name"] . '">';
            echo '<h3>' . $row["name"] . '</h3>';
            echo '<p>$' . $row["price"] . '</p>';
            echo '<form method="POST" action="cart.php">';
            echo '<input type="hidden" name="id" value="' . $row["id"] . '">';
            echo '<input type="hidden" name="name" value="' . $row["name"] . '">';
            echo '<input type="hidden" name="price" value="' . $row["price"] . '">';
            echo '<button type="submit" name="add_to_cart">Add to Cart</button>';
            echo '</form>';
            echo '</div>';
        }
    } else {
        echo "No products found.";
    }
    ?>
</div>

</body>
</html>

<?php $conn->close(); ?>
